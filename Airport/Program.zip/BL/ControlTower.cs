﻿using Airport.Models;

namespace Airport.BL
{
    public class ControlTower
    {
        static Station[] stations = new Station[4];

        public static void InitiazlizeStations()
        {
            for (int i = 0; i < 4; i++)
            {
                stations[i] = new Station();
            }
        }
        public static void LandToTakeoff(Guid airplaneId)
        {
            Console.WriteLine("Landed");
            for (int i = 0; i < 4; i++)
            {
                stations[i].AirplaneId = airplaneId;
                Console.WriteLine("you have entered station num: " + i);
                ControlStation.Enter(stations[i]);
                stations[i].AirplaneId = null;
                Console.WriteLine("you have Exited station number: " + i);
            }
            Takeoff();
        }
        public static void Takeoff()
        {
            Console.WriteLine("takoff");
        }
    }
}
