﻿using Airport.Models;

namespace Airport.BL
{
    public class ControlStation
    {
        static readonly SemaphoreSlim gate = new SemaphoreSlim(4);
        public static void Enter(Station station)
        {
            gate.WaitAsync();
            Thread.Sleep(3000);
            gate.Release();
        }
    }
}
