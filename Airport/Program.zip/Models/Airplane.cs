﻿namespace Airport.Models
{
    public class Airplane
    {
        public Guid Id { get; set; }
        //public AirplaneType Type { get; set; }
    }
    //public enum AirplaneType
    //{
    //    Passengers,
    //    Cargo
    //}
}
