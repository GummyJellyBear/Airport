﻿using System.Numerics;

namespace Airport.Models
{
    public class Station
    {
        public int Id { get; set; }
        public Guid? AirplaneId { get; set; }
    }
}
