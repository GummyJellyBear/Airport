﻿using Airport.Models;

namespace Airport.Data
{
    public class DataService
    {
        List<Station> Stations { get; set; }
        List<Airplane> Airplanes { get; set; }
    }
}
