﻿using Airport.BL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Airport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LandingController : ControllerBase
    {
        [HttpPost]
        public void LandToTakeoff()
        {
            ControlTower.InitiazlizeStations();
            ControlTower.LandToTakeoff(new Guid());
            ControlTower.LandToTakeoff(new Guid());
            ControlTower.LandToTakeoff(new Guid());
            ControlTower.LandToTakeoff(new Guid());

            //await Task.WhenAll(
            //    ControlTower.LandToTakeoff(new Guid()),
            //    ControlTower.LandToTakeoff(new Guid()),
            //    ControlTower.LandToTakeoff(new Guid()),
            //    ControlTower.LandToTakeoff(new Guid())
            //);
        }
    }
}
